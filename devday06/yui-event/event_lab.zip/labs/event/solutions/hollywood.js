/**
 * Example of an event driven application using CustomEvent
 */


YAHOO.example.Actor = function(p_name, p_desiredRoles) {
    this.name         = p_name;
    this.desiredRoles = p_desiredRoles || [];
    this.nextAudition = null;
};

YAHOO.example.Actor.prototype = {

    onRoleAvailable: function(role, args) {
        var castingCall = args[0];
        // castingCall.agency.rsvp(this);
        this.nextAudition = castingCall;
    },

    audition: function(ontime, performance) {
        var result = this.nextAudition.audition(this, ontime, performance);

        dump(result);

        // process result
    }

};

YAHOO.example.CastingCall = function(p_agency, p_source, p_role) {
    this.agency =   p_agency;
    this.source =   p_source;
    this.role   =   p_role;
};

YAHOO.example.CastingCall.prototype = {

    audition: function(actor, ontime, performance) {
        if (!ontime || performance == "horrible") {
            this.agency.auditionResult(this, "no");
            return "Better luck next time.";

        } else if (performance == "exceptional") {
            this.agency.auditionResult(this, "yes");
            return "Excellent, thank you, we'll contact your agent right " +
                   "away to discuss the next steps.";
                    
        } else {
            this.agency.auditionResult(this, "probably not");
            return "Don't call us; we'll call you.";
        }
    }

};

YAHOO.example.TalentAgency = function() {
    this.clients      = [];
    this.roleEvents   = [];
    this.castingCalls = [];
};

YAHOO.example.TalentAgency.prototype = {

    registerClient: function(actor) {
        this.clients.push(actor);

        for (var i=0, len=actor.desiredRoles.length; i<len; ++i) {
            var role = actor.desiredRoles[i];
            if (!this.roleEvents[role]) {
                this.roleEvents[role] = new YAHOO.util.CustomEvent(role, this);
            }

            this.roleEvents[role].subscribe(actor.onRoleAvailable, actor, true);

        }
    },

    notifyClients: function(castingCall) {
        this.castingCalls.push(castingCall);

        if (this.roleEvents[castingCall.role]) {
            this.roleEvents[castingCall.role].fire(castingCall);
        }
    },

    auditionResult: function(castingCall, result) {

        if (result == "no") {
            // drop client
        }

        // archive casting call
    }

};


YAHOO.example.hollywood = function() {


    return {

        go: function() {

            var moe = 
new YAHOO.example.Actor("Moe", ["male lead"]);

            var larry = 
new YAHOO.example.Actor("Larry", ["male lead", "male support"]);

            var curly = 
new YAHOO.example.Actor("Curly", ["comic sidekick"]);

            var headShots = new YAHOO.example.TalentAgency();

            headShots.registerClient(moe);
            headShots.registerClient(larry);
            headShots.registerClient(curly);
            
            var castingCall = 
new YAHOO.example.CastingCall(headShots, "Warner Bros", "male lead");

            headShots.notifyClients(castingCall);

            moe.audition(true, "horrible");
            moe.audition(false, "exceptional");

            larry.audition(true, "exceptional");
            larry.audition(true, "so so");
            
        }
        
    };

} ();


YAHOO.example.hollywood.go();

