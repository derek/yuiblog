<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<?php
include("yuil.php");
?>

<style>
#log {background-color:#99FF99; border:1px solid #000099; margin-bottom:8px; min-height:10px; padding:5px;}
#mover {background-color:#0000FF; color:#CCCCCC; border:1px solid #000000; margin-bottom:8px; height:100px; width:100px; position:relative;}

</style>

<script>
/*create namespace for examples:*/
YAHOO.namespace("example");

/* Using Crockford's "Module Pattern": */
YAHOO.example.onAvailableExample = function() {

	return {
		id: "onAvailableExample [JavaScriptObject]",
		init: function() {
			//we're going to set up our animation here, before
			//the page has loaded, using onAvailable to defer
			//execution until our "mover" div is available on the page.
			YAHOO.util.Event.onAvailable("mover", this.fnAnimSetup, this, true);
		},
		fnAnimSetup: function() {
			document.getElementById("log").innerHTML = "onAvailableExample.fnAnimSetup firing; this.id: " + this.id + "<br />" + document.getElementById("log").innerHTML;
			this.myAnim = new YAHOO.util.Anim("mover", { top: {to: 300} } );
			this.myAnim.onComplete.subscribe(this.onComplete, this, true);
			this.myAnim.animate();
		},
		onComplete: function(type, arguments, self) {
			document.getElementById("log").innerHTML = "onAvailableExample.onComplete firing; type: " + type + "; fps: " +  arguments[0].fps + "; duration: " + arguments[0].duration + "<br />" + document.getElementById("log").innerHTML;
		}
	}
} ();

YAHOO.example.onAvailableExample.init();


</script>
<title>Event Utility: Using Custom Event to Expose API Methods</title>
</head>
<body>

<body id="yahoo"><!-- id: optional property or feature signature -->
<div id="doc" class="yui-t5"><!-- possible values: t1, t2, t3, t4, t5, t6, t7 -->
	<div id="hd">
		<h1>Event Utility: Using Custom Event to Expose API Methods</h1>
	</div>
	<div id="bd">

		<!-- start: primary column from outer template -->
		<div id="yui-main">
			<div class="yui-b">
				<!--target div for simple logging-->
				<div id="log">
					
				</div>
				
				<div id="mover">
					I will move automatically as soon as the Event Utility detects that I'm available.
				</div>
			</div>
		</div>
		<!-- end: primary column from outer template -->
		
		<!-- start: secondary column from outer template -->
		<div class="yui-b">
			
		</div>
		<!-- end: secondary column from outer template -->
		
	</div>
	<?php
	flush();
	sleep(5);
	?>
	<div id="ft">
			<p>Footer: Small font, generally used for copyright and other boilerplate content.</p>
	</div>
</div>

</body>
</html>
