

<!--Yahoo! User Interface Library: http://twiki.corp.yahoo.com/view/Devel/PresentationPlatform-->

<!--Begin YUI CSS infrastructure, including Standard Reset, Standard Fonts, and CSS Page Grids -->
<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/css/reset_2.0.0-b3.css" />
<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/css/fonts_2.0.0-b3.css" />
<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/css/grids_2.0.0-b3.css" />
<!--end YUI CSS infrastructure-->

<!--begin YUIL Utilities -->
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/yahoo_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/event_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/dragdrop_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/connection_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/animation_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/dom_2.0.0-b3.js"></script>

<!-- OPTIONAL: JSON (not required if not using JSON data) -->
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/utils/2/json_2.0.0-b3.js"></script>
<!--end YUIL Utilities-->

<!--begin YUIL Widgets/Controls, including CSS where supported-->
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/slider/slider_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/treeview/treeview_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/calendar/calendar_2.0.0-b1.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/autocomplete/autocomplete_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/container/container_2.0.0-b3.js"></script>
<script src="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/menu/menu_2.0.0-b3.js"></script>

<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/treeview/css/default/treeview_2.0.0-b3.css" />
<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/calendar/css/calendar_2.0.0-b3.css" />
<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/container/css/container_2.0.0-b3.css" />
<link rel="stylesheet" type="text/css" href="http://us.js2.yimg.com/us.js.yimg.com/lib/common/widgets/2/menu/css/menu_2.0.0-b3.css" />
<!--end Yahoo YUIL Widgets/Controls-->

<!--end Yahoo User Interface Library-->

