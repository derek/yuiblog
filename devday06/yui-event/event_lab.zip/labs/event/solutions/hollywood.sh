js -f assets/console.js -f assets/yahoo.js -f assets/event-raw.js hollywood.js

