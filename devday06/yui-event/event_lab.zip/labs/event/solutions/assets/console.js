// Stub out some browser objects so some lower-level utils will work in the console
window     = {};
navigator  = {userAgent: "console"};
document   = {};
setTimeout = function() {};

if ("undefined" == typeof dump) { dump = print; }
