<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<?php
include("yuil.php");
?>

<style>
#log {background-color:#99FF99; border:1px solid #000099; margin-bottom:8px; min-height:10px; padding:5px; margin-top:10px;}

#publisher {background-color:#990033; color:#FFFFFF; border:1px solid black;}
#publisher_click1 {background-color:#FF9900; cursor:pointer; margin:3px;}
#publisher_click2 {background-color:#FFCC00; cursor:pointer; margin:3px;}
#publisher_click3 {background-color:#FFCC66; cursor:pointer; margin:3px;}

#subscribers {background-color:#000099; color:#FFFFFF; border:1px solid black;}
#subscriber1 {background-color:#00CCFF; margin:3px;}
#subscriber2 {background-color:#6699CC; margin:3px;}
#subscriber3 {background-color:#33CCFF; margin:3px;}

</style>

<script>
/* Using Crockford's "Module Pattern": */
YAHOO.example.Publisher = function() {

	return {
		id: "publisher",
		init: function() {
			this.myCustomEvent = new YAHOO.util.CustomEvent("myCustomEvent", this);
			YAHOO.util.Event.addListener("publisher","click",this.myEventHandler,this,true);
		},
		myEventHandler: function(e, obj) {
			//get id of clicked element
			var clickedId = (YAHOO.util.Event.getTarget(e).id) ? YAHOO.util.Event.getTarget(e).id : YAHOO.util.Event.getTarget(e).parentNode.id;
			this.myCustomEvent.fire(clickedId, this.id, new Date());
			document.getElementById("log").innerHTML = "Publisher: myEventHandler firing; this.id: " + this.id + "; clickedId: " + clickedId + "<br />" + document.getElementById("log").innerHTML;
		}
	}
} ();

YAHOO.example.Subscriber1 = function() {

	return {
		id: "subscriber1",
		init: function() {
			YAHOO.example.Publisher.myCustomEvent.subscribe(this.myEventHandler, this, true);
		},
		myEventHandler: function(type, args, obj) {
			//alert("here");
			//this method is called when the custom event fires
			document.getElementById(this.id).innerHTML = "The id of the clicked element was: " + args[0];
		}
	}
} ();

YAHOO.example.Subscriber2 = function() {

	return {
		id: "subscriber2",
		init: function() {
			YAHOO.example.Publisher.myCustomEvent.subscribe(this.myEventHandler, this, true);
		},
		myEventHandler: function(type, args, obj) {
			//this method is called when the custom event fires
			document.getElementById(this.id).innerHTML = "The timestamp that we passed when the Custom Event fired was: " + args[2];
		}
	}
} ();

YAHOO.example.Subscriber3 = function() {

	return {
		id: "subscriber3",
		init: function() {
			YAHOO.example.Publisher.myCustomEvent.subscribe(this.myEventHandler, this, true);
		},
		myEventHandler: function(type, args, obj) {
			//this method is called when the custom event fires
			document.getElementById(this.id).innerHTML = "'this' refers to the object whose 'id' property is: " + this.id + "; the publisher's id is " + args[1];
		}
	}
} ();



YAHOO.example.Publisher.init();
YAHOO.example.Subscriber1.init();
YAHOO.example.Subscriber2.init();
YAHOO.example.Subscriber3.init();


</script>
<title>Lab: Using Custom Events</title>
</head>
<body>

<body id="yahoo"><!-- id: optional property or feature signature -->
<div id="doc" class="yui-t1"><!-- possible values: t1, t2, t3, t4, t5, t6, t7 -->
	<div id="hd">
		<h1>Lab: Using Custom Events</h1>
	</div>
	<div id="bd">

		<!-- start: primary column from outer template -->
		<div id="yui-main">
			<div class="yui-b">
				<div id="subscribers">
					<strong>Subscribers</strong>
					<div id="subscriber1">Subscriber 1</div>
					<div id="subscriber2">Subscriber 2</div>
					<div id="subscriber3">Subscriber 3</div>
				</div>


				<!--target div for simple logging-->
				<div id="log">
					
				</div>

			</div>
		</div>
		<!-- end: primary column from outer template -->
		
		<!-- start: secondary column from outer template -->
		<div class="yui-b">
			<div id="publisher">
				<strong>Publisher</strong>
				<div id="publisher_click1">Click 1</div>
				<div id="publisher_click2">Click 2</div>
				<div id="publisher_click3">Click 3</div>
			</div>
		</div>
		<!-- end: secondary column from outer template -->
		
	</div>

	<div id="ft">
			<p>Footer: Small font, generally used for copyright and other boilerplate content.</p>
	</div>
</div>

</body>
</html>
